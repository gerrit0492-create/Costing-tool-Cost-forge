from __future__ import annotations
import streamlit as st

st.set_page_config(page_title="Cost Tool", layout="wide")
st.title("Welkom bij Cost Tool")
st.write("Gebruik het menu links om naar **Quick Cost Check** te gaan.")
